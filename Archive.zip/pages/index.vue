<template>
    <div>
    </div>
</template>

<script setup>
 definePageMeta({
     middleware: 'auth' // this should match the name of the file inside the middleware directory 
})

const router = useRouter();
onMounted(() => {
    router.push('/autopark');
})
</script>

<style lang="scss" scoped>

</style>