<template>
    <div>
        <div class="flex justify-start items-start">
            <Aside></Aside>
            <div class="flex-1">
                <Navbar />
                <NuxtPage  />
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>